#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;

// Adds a menu item: Tools > Stranded Frequency > Build Ending Screen
// Builds the ending screen inside the scene's Canvas, measured from Jason's final main menu.
// This file must live in a folder named "Editor".
public static class BuildEndingScreen
{
    // Colors sampled from the final menu
    static readonly Color BgTop = Hex("#17364F");
    static readonly Color BgBottom = Hex("#081321");
    static readonly Color SquareTop = Hex("#1A3C55");
    static readonly Color SquareBottom = Hex("#336B84");
    static readonly Color LineTeal = Hex("#65D7C5");
    static readonly Color TitleText = Hex("#D4F7F4");
    static readonly Color CornerText = Hex("#7AABB8");
    static readonly Color ButtonFill = Hex("#174D59");
    static readonly Color FrameFill = Hex("#0E2433");

    // Waveform corners: x runs 0 to 1 across the screen, y is pixels from the screen center
    static readonly Vector2[] WavePoints =
    {
            new Vector2(0.0000f, 229f),
            new Vector2(0.0964f, 229f),
            new Vector2(0.1152f, 289f),
            new Vector2(0.1443f, 230f),
            new Vector2(0.1892f, 324f),
            new Vector2(0.2246f, 206f),
            new Vector2(0.2486f, 324f),
            new Vector2(0.2684f, 273f),
            new Vector2(0.2871f, 265f),
            new Vector2(0.3403f, 265f),
            new Vector2(0.3637f, 306f),
            new Vector2(0.3908f, 246f),
            new Vector2(0.4174f, 347f),
            new Vector2(0.4596f, 226f),
            new Vector2(0.4987f, 336f),
            new Vector2(0.5258f, 252f),
            new Vector2(0.5534f, 290f),
            new Vector2(0.6477f, 294f),
            new Vector2(0.6795f, 244f),
            new Vector2(0.7066f, 325f),
            new Vector2(0.7426f, 222f),
            new Vector2(0.7650f, 319f),
            new Vector2(0.7905f, 276f),
            new Vector2(0.8583f, 276f),
            new Vector2(0.8786f, 347f),
            new Vector2(0.8942f, 281f),
            new Vector2(0.9125f, 282f),
            new Vector2(0.9260f, 346f),
            new Vector2(0.9427f, 276f),
            new Vector2(1.0000f, 276f)
    };

    // Background squares: x, y (center, from screen center), size
    static readonly Vector4[] Squares =
    {
            new Vector4(-564f, 512f, 15f, 0),
            new Vector4(485f, 512f, 16f, 0),
            new Vector4(745f, 494f, 34f, 0),
            new Vector4(802f, 418f, 16f, 0),
            new Vector4(-912f, 398f, 15f, 0),
            new Vector4(-353f, 376f, 15f, 0),
            new Vector4(180f, 340f, 16f, 0),
            new Vector4(899f, 212f, 15f, 0),
            new Vector4(69f, 182f, 15f, 0),
            new Vector4(-191f, 171f, 23f, 0),
            new Vector4(-884f, 168f, 16f, 0),
            new Vector4(-406f, 148f, 26f, 0),
            new Vector4(267f, 154f, 15f, 0),
            new Vector4(746f, 122f, 33f, 0),
            new Vector4(519f, 106f, 16f, 0),
            new Vector4(-830f, 53f, 44f, 0),
            new Vector4(-578f, 24f, 15f, 0),
            new Vector4(906f, -28f, 30f, 0),
            new Vector4(-260f, -28f, 16f, 0),
            new Vector4(269f, -67f, 34f, 0),
            new Vector4(713f, -62f, 15f, 0),
            new Vector4(0f, -73f, 16f, 0),
            new Vector4(534f, -73f, 16f, 0),
            new Vector4(-453f, -86f, 32f, 0),
            new Vector4(-686f, -142f, 36f, 0),
            new Vector4(-859f, -156f, 15f, 0),
            new Vector4(839f, -196f, 15f, 0),
            new Vector4(383f, -231f, 13f, 0),
            new Vector4(633f, -248f, 34f, 0),
            new Vector4(-432f, -319f, 9f, 0),
            new Vector4(-745f, -352f, 29f, 0),
            new Vector4(527f, -374f, 31f, 0),
            new Vector4(817f, -378f, 16f, 0),
            new Vector4(324f, -439f, 13f, 0)
    };

    static Font fallback, titleFont, buttonFont, bodyFont;

    [MenuItem("Tools/Stranded Frequency/Build Ending Screen")]
    public static void Build()
    {
        Canvas canvas = Object.FindFirstObjectByType<Canvas>();
        if (canvas == null)
        {
            EditorUtility.DisplayDialog("No Canvas found",
                "Add a Canvas first (Hierarchy + > UI > Canvas), then run this again.", "OK");
            return;
        }

        Transform existing = canvas.transform.Find("EndingPanel");
        if (existing != null)
        {
            bool replace = EditorUtility.DisplayDialog("Replace EndingPanel?",
                "An EndingPanel already exists. Replace it with a fresh one? (Cmd+Z undoes this.)",
                "Replace", "Cancel");
            if (!replace) return;
            Undo.DestroyObjectImmediate(existing.gameObject);
        }

        fallback = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        titleFont = FindFont("Orbitron-Black");
        buttonFont = FindFont("Orbitron-Medium");
        bodyFont = FindFont("SourceSans3-Regular");

        // Panel with the menu's top-to-bottom gradient
        GameObject panel = NewUI("EndingPanel", canvas.transform);
        Stretch(panel);
        UIGradient bg = panel.AddComponent<UIGradient>();
        bg.topColor = BgTop;
        bg.bottomColor = BgBottom;
        AudioSource voice = panel.AddComponent<AudioSource>();
        voice.playOnAwake = false;

        // Background squares, same spots and shading as the menu
        GameObject squares = NewUI("BackgroundSquares", panel.transform);
        Stretch(squares);
        foreach (Vector4 s in Squares)
        {
            GameObject sq = NewUI("Square", squares.transform);
            Place(sq, new Vector2(s.x, s.y), new Vector2(s.z, s.z));
            UIGradient g = sq.AddComponent<UIGradient>();
            g.topColor = SquareTop;
            g.bottomColor = SquareBottom;
            g.raycastTarget = false;
        }

        // Corner labels
        Corner(panel, "Label_TopLeft", "OBSERVATORY TERMINAL", new Vector2(0, 1), TextAnchor.UpperLeft, new Vector2(32, -14));
        Corner(panel, "Label_TopRight", "SIGNAL DECODED", new Vector2(1, 1), TextAnchor.UpperRight, new Vector2(-24, -14));
        Corner(panel, "Label_BottomLeft", "FREQ: 1420.4 MHZ", new Vector2(0, 0), TextAnchor.LowerLeft, new Vector2(33, 24));
        Corner(panel, "Label_BottomRight", "TRANSMISSION RECEIVED", new Vector2(1, 0), TextAnchor.LowerRight, new Vector2(-24, 24));

        // Title
        Label(panel, "Title", "SIGNAL RESOLVED", titleFont, 104, TitleText, TextAnchor.MiddleCenter,
              new Vector2(0, 448), new Vector2(1880, 140));

        // Waveform line, traced from the menu
        GameObject line = NewUI("WaveformLine", panel.transform);
        Stretch(line);
        WaveformLine wave = line.AddComponent<WaveformLine>();
        wave.points = (Vector2[])WavePoints.Clone();
        wave.color = LineTeal;
        wave.thickness = 5f;
        wave.raycastTarget = false;

        // Furcifer image frame (left)
        GameObject furcifer = NewUI("FurciferImage", panel.transform);
        Place(furcifer, new Vector2(-420, -55), new Vector2(440, 440));
        Image furImg = furcifer.AddComponent<Image>();
        furImg.color = FrameFill;
        furImg.preserveAspect = true;
        furImg.raycastTarget = false;
        Outline frame = furcifer.AddComponent<Outline>();
        frame.effectColor = LineTeal;
        frame.effectDistance = new Vector2(3, -3);
        Label(furcifer, "PlaceholderLabel", "[ Furcifer art goes here ]", bodyFont, 28, CornerText,
              TextAnchor.MiddleCenter, Vector2.zero, new Vector2(420, 100));

        // Subtitles (right)
        Text subtitles = Label(panel, "Subtitles", "", bodyFont, 42, TitleText, TextAnchor.MiddleLeft,
              new Vector2(380, -55), new Vector2(760, 420)).GetComponent<Text>();

        // Play Again button, same style as the menu buttons
        GameObject buttonGO = NewUI("PlayAgainButton", panel.transform);
        Place(buttonGO, new Vector2(0, -405), new Vector2(472, 82));
        Image buttonImg = buttonGO.AddComponent<Image>();
        buttonImg.color = ButtonFill;
        Outline buttonOutline = buttonGO.AddComponent<Outline>();
        buttonOutline.effectColor = LineTeal;
        buttonOutline.effectDistance = new Vector2(3, -3);
        Button button = buttonGO.AddComponent<Button>();
        button.targetGraphic = buttonImg;
        ColorBlock colors = button.colors;
        colors.highlightedColor = new Color(1.25f, 1.25f, 1.25f, 1f);
        colors.pressedColor = new Color(0.8f, 0.8f, 0.8f, 1f);
        button.colors = colors;
        GameObject buttonText = Label(buttonGO, "Text", "Play Again", buttonFont, 42, TitleText,
              TextAnchor.MiddleCenter, Vector2.zero, Vector2.zero);
        Stretch(buttonText);

        // Wire up the EndingScreen script
        EndingScreen ending = panel.AddComponent<EndingScreen>();
        ending.voiceLog = voice;
        ending.subtitleText = subtitles;
        ending.playAgainButton = buttonGO;
        UnityEventTools.AddPersistentListener(button.onClick, ending.PlayAgain);

        Undo.RegisterCreatedObjectUndo(panel, "Build Ending Screen");
        EditorSceneManager.MarkSceneDirty(panel.scene);
        Selection.activeGameObject = panel;

        string missing = "";
        if (titleFont == null) missing += " Orbitron-Black.ttf";
        if (buttonFont == null) missing += " Orbitron-Medium.ttf";
        if (bodyFont == null) missing += " SourceSans3-Regular.ttf";
        if (missing != "")
            Debug.LogWarning("Ending screen built, but these fonts were not found in the project:" + missing +
                             ". Add them to Assets/Fonts and run Build Ending Screen again.");
        else
            Debug.Log("Ending screen built with all fonts.");
    }

    // ---------- helpers ----------

    static GameObject NewUI(string name, Transform parent)
    {
        GameObject go = new GameObject(name, typeof(RectTransform));
        go.layer = LayerMask.NameToLayer("UI");
        go.transform.SetParent(parent, false);
        return go;
    }

    static void Place(GameObject go, Vector2 pos, Vector2 size)
    {
        RectTransform rt = (RectTransform)go.transform;
        rt.anchorMin = rt.anchorMax = rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;
    }

    static void Stretch(GameObject go)
    {
        RectTransform rt = (RectTransform)go.transform;
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
    }

    static GameObject Label(GameObject parent, string name, string text, Font font, int size, Color color,
                            TextAnchor align, Vector2 pos, Vector2 boxSize)
    {
        GameObject go = NewUI(name, parent.transform);
        Place(go, pos, boxSize);
        Text t = go.AddComponent<Text>();
        t.font = font != null ? font : fallback;
        t.text = text;
        t.fontSize = size;
        t.color = color;
        t.alignment = align;
        t.horizontalOverflow = HorizontalWrapMode.Wrap;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.raycastTarget = false;
        return go;
    }

    static void Corner(GameObject parent, string name, string text, Vector2 corner, TextAnchor align, Vector2 offset)
    {
        GameObject go = Label(parent, name, text, bodyFont, 22, CornerText, align, Vector2.zero, new Vector2(600, 40));
        RectTransform rt = (RectTransform)go.transform;
        rt.anchorMin = rt.anchorMax = rt.pivot = corner;
        rt.anchoredPosition = offset;
    }

    static Font FindFont(string fileName)
    {
        foreach (string guid in AssetDatabase.FindAssets(fileName + " t:Font"))
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            if (System.IO.Path.GetFileNameWithoutExtension(path) == fileName)
                return AssetDatabase.LoadAssetAtPath<Font>(path);
        }
        return null;
    }

    static Color Hex(string hex)
    {
        ColorUtility.TryParseHtmlString(hex, out Color c);
        return c;
    }
}
#endif
