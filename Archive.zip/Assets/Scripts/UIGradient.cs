using UnityEngine;
using UnityEngine.UI;

// A UI background that fades from one color at the top to another at the bottom.
[RequireComponent(typeof(CanvasRenderer))]
public class UIGradient : MaskableGraphic
{
    public Color topColor = new Color32(0x18, 0x37, 0x4C, 0xFF);
    public Color bottomColor = new Color32(0x07, 0x15, 0x1E, 0xFF);

    protected override void OnPopulateMesh(VertexHelper vh)
    {
        vh.Clear();
        Rect r = rectTransform.rect;
        vh.AddVert(new Vector3(r.xMin, r.yMin), bottomColor * color, Vector2.zero);
        vh.AddVert(new Vector3(r.xMin, r.yMax), topColor * color, Vector2.zero);
        vh.AddVert(new Vector3(r.xMax, r.yMax), topColor * color, Vector2.zero);
        vh.AddVert(new Vector3(r.xMax, r.yMin), bottomColor * color, Vector2.zero);
        vh.AddTriangle(0, 1, 2);
        vh.AddTriangle(2, 3, 0);
    }

#if UNITY_EDITOR
    protected override void OnValidate()
    {
        base.OnValidate();
        SetVerticesDirty();
    }
#endif
}
