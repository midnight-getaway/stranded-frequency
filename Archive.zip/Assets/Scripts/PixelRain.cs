using UnityEngine;
using UnityEngine.UI;

// Spawns pixel squares that drift down the screen like rain, matching the main menu.
// Add this to an empty UI object inside the Canvas. It fills the screen on its own.
[RequireComponent(typeof(RectTransform))]
public class PixelRain : MonoBehaviour
{
    public int count = 14;
    public Vector2 sizeRange = new Vector2(8, 34);
    [Tooltip("Pixels per second.")]
    public Vector2 speedRange = new Vector2(25, 90);
    public Color topColor = new Color32(0x1A, 0x3C, 0x55, 0xFF);
    public Color bottomColor = new Color32(0x33, 0x6B, 0x84, 0xFF);

    RectTransform area;
    RectTransform[] drops;
    float[] speeds;

    void Awake()
    {
        area = (RectTransform)transform;
        area.anchorMin = Vector2.zero;
        area.anchorMax = Vector2.one;
        area.offsetMin = area.offsetMax = Vector2.zero;
    }

    void Start()
    {
        drops = new RectTransform[count];
        speeds = new float[count];
        Rect r = area.rect;

        for (int i = 0; i < count; i++)
        {
            GameObject go = new GameObject("Drop", typeof(RectTransform));
            go.layer = gameObject.layer;
            go.transform.SetParent(transform, false);

            UIGradient g = go.AddComponent<UIGradient>();
            g.topColor = topColor;
            g.bottomColor = bottomColor;
            g.raycastTarget = false;

            RectTransform rt = (RectTransform)go.transform;
            rt.anchorMin = rt.anchorMax = rt.pivot = new Vector2(0.5f, 0.5f);
            float size = Mathf.Round(Random.Range(sizeRange.x, sizeRange.y));
            rt.sizeDelta = new Vector2(size, size);
            rt.anchoredPosition = new Vector2(Random.Range(r.xMin, r.xMax), Random.Range(r.yMin, r.yMax));

            drops[i] = rt;
            speeds[i] = Random.Range(speedRange.x, speedRange.y);
        }
    }

    void Update()
    {
        if (drops == null) return;
        Rect r = area.rect;

        for (int i = 0; i < drops.Length; i++)
        {
            RectTransform rt = drops[i];
            Vector2 p = rt.anchoredPosition;
            p.y -= speeds[i] * Time.unscaledDeltaTime;

            float half = rt.sizeDelta.y * 0.5f;
            if (p.y < r.yMin - half)
            {
                // Back to the top at a new spot and speed
                p.y = r.yMax + half;
                p.x = Random.Range(r.xMin, r.xMax);
                speeds[i] = Random.Range(speedRange.x, speedRange.y);
            }
            rt.anchoredPosition = p;
        }
    }
}
