using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

// Runs the ending screen: plays the voice log, types out Furcifer's message letter by letter
// (pausing at "...", commas and periods for drama), then shows the credits and the Play Again button.
public class EndingScreen : MonoBehaviour
{
    [Header("Hooked up automatically by the builder")]
    public AudioSource voiceLog;
    public Text subtitleText;
    public GameObject credits;
    public GameObject playAgainButton;

    [Header("Furcifer's message")]
    [TextArea(2, 4)]
    public string[] subtitleLines =
    {
        "[Furcifer's message, line 1]",
        "[Furcifer's message, line 2]",
        "[Furcifer's message, line 3]"
    };
    [Tooltip("How long each line stays on screen AFTER it finishes typing.")]
    public float secondsPerLine = 2f;

    [Header("Typewriter")]
    [Tooltip("Letters typed per second. Lower = slower, more dramatic.")]
    public float lettersPerSecond = 28f;
    [Tooltip("Pause after each dot in \"...\" (the dots appear one at a time).")]
    public float ellipsisDotPause = 0.35f;
    [Tooltip("Pause after a comma.")]
    public float commaPause = 0.25f;
    [Tooltip("Pause after a period, ! or ?")]
    public float sentencePause = 0.5f;
    [Tooltip("Quiet beat before the first line starts typing.")]
    public float startDelay = 1f;

    [Header("Flow")]
    [Tooltip("ON: the ending plays as soon as this scene loads. Keep this ON if the game loads the " +
             "ending scene when the last puzzle is solved.")]
    public bool previewOnStart = true;

    [Tooltip("Scene to load when the player clicks Play Again. Must match the scene name exactly " +
             "and be in File > Build Profiles > Scene List.")]
    public string playAgainScene = "MainMenu";

    [HideInInspector] public bool isTyping;

    void Start()
    {
        if (previewOnStart) Show();
    }

    // Call this to start the ending if it's ever shown inside another scene.
    public void Show()
    {
        gameObject.SetActive(true);
        StopAllCoroutines();

        if (credits != null) credits.SetActive(false);
        if (playAgainButton != null) playAgainButton.SetActive(false);
        if (subtitleText != null) subtitleText.text = "";

        if (voiceLog != null && voiceLog.clip != null) voiceLog.Play();
        StartCoroutine(PlaySubtitles());
    }

    IEnumerator PlaySubtitles()
    {
        yield return new WaitForSeconds(startDelay);

        foreach (string line in subtitleLines)
        {
            yield return TypeLine(line);
            yield return new WaitForSeconds(secondsPerLine);
        }

        if (subtitleText != null) subtitleText.text = "";
        if (credits != null) credits.SetActive(true);
        if (playAgainButton != null) playAgainButton.SetActive(true);
    }

    IEnumerator TypeLine(string line)
    {
        if (subtitleText == null || string.IsNullOrEmpty(line)) yield break;

        isTyping = true;
        float letterDelay = 1f / Mathf.Max(1f, lettersPerSecond);
        subtitleText.text = "";

        for (int i = 0; i < line.Length; i++)
        {
            char c = line[i];
            subtitleText.text = line.Substring(0, i + 1);

            bool isDot = c == '.';
            bool partOfEllipsis = isDot &&
                ((i > 0 && line[i - 1] == '.') || (i + 1 < line.Length && line[i + 1] == '.'));

            if (c == '…')                          // a single "…" character
                yield return new WaitForSeconds(ellipsisDotPause * 3f);
            else if (partOfEllipsis)                     // each dot of "..." lands slowly
                yield return new WaitForSeconds(ellipsisDotPause);
            else if (c == ',')
                yield return new WaitForSeconds(commaPause);
            else if (isDot || c == '!' || c == '?')
                yield return new WaitForSeconds(sentencePause);
            else
                yield return new WaitForSeconds(letterDelay);
        }

        isTyping = false;
    }

    // Sends the player back to the main menu.
    public void PlayAgain()
    {
        if (Application.CanStreamedLevelBeLoaded(playAgainScene))
            SceneManager.LoadScene(playAgainScene);
        else
            Debug.LogError("Play Again can't load \"" + playAgainScene + "\". Check the name, and add it " +
                           "under File > Build Profiles > Scene List.");
    }
}