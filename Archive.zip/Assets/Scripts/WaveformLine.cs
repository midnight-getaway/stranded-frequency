using UnityEngine;
using UnityEngine.UI;

// Draws a jagged signal line (like the main menu mockup) as a UI element.
// X values run 0 to 1 across the element's width. Y values are pixels up or down from its center.
[RequireComponent(typeof(CanvasRenderer))]
public class WaveformLine : MaskableGraphic
{
    public float thickness = 4f;

    [Tooltip("1 = full spikes, 0 = flat line. Can be animated.")]
    [Range(0f, 1.5f)] public float amplitude = 1f;

    public Vector2[] points =
    {
            new Vector2(0.000f, -45f),
            new Vector2(0.097f, -45f),
            new Vector2(0.116f, 13f),
            new Vector2(0.144f, -45f),
            new Vector2(0.189f, 51f),
            new Vector2(0.222f, -68f),
            new Vector2(0.249f, 47f),
            new Vector2(0.278f, -9f),
            new Vector2(0.341f, -9f),
            new Vector2(0.361f, 30f),
            new Vector2(0.389f, -26f),
            new Vector2(0.417f, 77f),
            new Vector2(0.459f, -45f),
            new Vector2(0.500f, 60f),
            new Vector2(0.528f, -21f),
            new Vector2(0.553f, 17f),
            new Vector2(0.647f, 19f),
            new Vector2(0.678f, -30f),
            new Vector2(0.706f, 53f),
            new Vector2(0.742f, -49f),
            new Vector2(0.767f, 43f),
            new Vector2(0.791f, 0f),
            new Vector2(0.858f, 0f),
            new Vector2(0.878f, 75f),
            new Vector2(0.896f, 6f),
            new Vector2(0.913f, 6f),
            new Vector2(0.927f, 68f),
            new Vector2(0.944f, 0f),
            new Vector2(1.000f, 0f)
    };

    protected override void OnPopulateMesh(VertexHelper vh)
    {
        vh.Clear();
        if (points == null || points.Length < 2) return;

        Rect r = rectTransform.rect;
        Vector2 Map(Vector2 p) => new Vector2(r.xMin + p.x * r.width, r.center.y + p.y * amplitude);

        for (int i = 0; i < points.Length - 1; i++)
        {
            Vector2 a = Map(points[i]);
            Vector2 b = Map(points[i + 1]);
            Vector2 dir = (b - a).normalized;
            Vector2 normal = new Vector2(-dir.y, dir.x) * (thickness * 0.5f);

            // Stretch each piece slightly so corners don't show gaps
            a -= dir * (thickness * 0.5f);
            b += dir * (thickness * 0.5f);

            int start = vh.currentVertCount;
            vh.AddVert(a - normal, color, Vector2.zero);
            vh.AddVert(a + normal, color, Vector2.zero);
            vh.AddVert(b + normal, color, Vector2.zero);
            vh.AddVert(b - normal, color, Vector2.zero);
            vh.AddTriangle(start, start + 1, start + 2);
            vh.AddTriangle(start + 2, start + 3, start);
        }
    }

#if UNITY_EDITOR
    protected override void OnValidate()
    {
        base.OnValidate();
        SetVerticesDirty();
    }
#endif
}
