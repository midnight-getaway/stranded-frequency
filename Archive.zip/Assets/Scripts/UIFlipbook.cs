using UnityEngine;
using UnityEngine.UI;

// Plays a list of sprites in a loop on a UI Image, like a flipbook.
// Put this on the same object as the Image (for example FurciferImage) and drag the frames into Frames.
[RequireComponent(typeof(Image))]
public class UIFlipbook : MonoBehaviour
{
    public Sprite[] frames;
    [Tooltip("Frames per second. 8 to 12 works well for pixel art.")]
    public float fps = 10f;
    public bool loop = true;

    Image image;
    float timer;
    int index;

    void Awake()
    {
        image = GetComponent<Image>();
    }

    void OnEnable()
    {
        timer = 0f;
        index = 0;
        if (frames != null && frames.Length > 0) image.sprite = frames[0];
    }

    void Update()
    {
        if (frames == null || frames.Length < 2 || fps <= 0f) return;

        timer += Time.unscaledDeltaTime;
        float frameTime = 1f / fps;
        while (timer >= frameTime)
        {
            timer -= frameTime;
            index++;
            if (index >= frames.Length)
            {
                if (!loop) { index = frames.Length - 1; enabled = false; break; }
                index = 0;
            }
            image.sprite = frames[index];
        }
    }
}
