using UnityEngine;
using UnityEngine.UI;

// A phone-call style audio waveform (bouncing bars) that plays while Furcifer's subtitles are on screen.
// If the voice log has an audio clip, the bars follow the real sound. Otherwise they fake natural speech.
// Add this to an empty UI object under EndingPanel. It finds the subtitles and audio on its own.
[RequireComponent(typeof(RectTransform))]
public class VoiceVisualizer : MonoBehaviour
{
    [Header("Look")]
    public int barCount = 32;
    public float barWidth = 8f;
    public float barGap = 6f;
    public float minHeight = 4f;
    public float maxHeight = 80f;
    public Color barColor = new Color32(0x65, 0xD7, 0xC5, 0xFF);

    [Header("Motion")]
    [Tooltip("How fast the bars react. Higher = snappier.")]
    public float smoothing = 14f;
    [Tooltip("Speed of the fake speech when there is no audio clip.")]
    public float speechSpeed = 6f;
    public float fadeSpeed = 4f;

    [Header("Found automatically if left empty")]
    public Text subtitleText;
    public AudioSource voiceLog;

    RectTransform[] bars;
    float[] heights;
    float[] spectrum = new float[64];
    CanvasGroup group;

    // Runs when the component is first added in the editor: sets a good size and spot (under the subtitles).
    void Reset()
    {
        RectTransform rt = (RectTransform)transform;
        rt.anchorMin = rt.anchorMax = rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = new Vector2(380, -240);
        rt.sizeDelta = new Vector2(barCount * (barWidth + barGap), maxHeight);
    }

    void Awake()
    {
        EndingScreen ending = GetComponentInParent<EndingScreen>(true);
        if (ending != null)
        {
            if (subtitleText == null) subtitleText = ending.subtitleText;
            if (voiceLog == null) voiceLog = ending.voiceLog;
        }

        group = GetComponent<CanvasGroup>();
        if (group == null) group = gameObject.AddComponent<CanvasGroup>();
        group.alpha = 0f;
        group.blocksRaycasts = false;
        group.interactable = false;

        BuildBars();
    }

    void BuildBars()
    {
        bars = new RectTransform[barCount];
        heights = new float[barCount];
        float total = barCount * barWidth + (barCount - 1) * barGap;
        float startX = -total / 2f + barWidth / 2f;

        for (int i = 0; i < barCount; i++)
        {
            GameObject go = new GameObject("Bar", typeof(RectTransform));
            go.layer = gameObject.layer;
            go.transform.SetParent(transform, false);
            Image img = go.AddComponent<Image>();
            img.color = barColor;
            img.raycastTarget = false;

            RectTransform rt = (RectTransform)go.transform;
            rt.anchorMin = rt.anchorMax = rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = new Vector2(startX + i * (barWidth + barGap), 0);
            rt.sizeDelta = new Vector2(barWidth, minHeight);
            bars[i] = rt;
            heights[i] = minHeight;
        }
    }

    void Update()
    {
        bool talking = subtitleText != null && !string.IsNullOrEmpty(subtitleText.text);
        group.alpha = Mathf.MoveTowards(group.alpha, talking ? 1f : 0f, fadeSpeed * Time.unscaledDeltaTime);

        bool realAudio = voiceLog != null && voiceLog.clip != null && voiceLog.isPlaying;
        if (realAudio) voiceLog.GetSpectrumData(spectrum, 0, FFTWindow.BlackmanHarris);

        float t = Time.unscaledTime * speechSpeed;
        // Slow "syllable" pulse so fake speech rises and falls like talking
        float loudness = Mathf.Clamp01(Mathf.PerlinNoise(t * 0.35f, 7.3f) * 1.6f - 0.25f);

        for (int i = 0; i < barCount; i++)
        {
            float center = 1f - Mathf.Abs((i / (float)(barCount - 1)) * 2f - 1f); // taller in the middle
            float level;

            if (realAudio)
            {
                int bin = Mathf.Min(spectrum.Length - 1, Mathf.Abs(i - barCount / 2) + 1);
                level = Mathf.Clamp01(spectrum[bin] * 40f) * (0.5f + 0.5f * center);
            }
            else if (talking)
            {
                float n = Mathf.PerlinNoise(t + i * 0.37f, i * 1.7f);
                level = n * loudness * (0.35f + 0.65f * center);
            }
            else
            {
                level = 0f;
            }

            float target = Mathf.Lerp(minHeight, maxHeight, level);
            heights[i] = Mathf.Lerp(heights[i], target, 1f - Mathf.Exp(-smoothing * Time.unscaledDeltaTime));
            bars[i].sizeDelta = new Vector2(barWidth, heights[i]);
        }
    }
}
