#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;

// Adds a menu item: Tools > Stranded Frequency > Add Credits
// Adds a Credits text to the existing ending screen without touching anything else.
// The credits appear after Furcifer's message, together with the Play Again button.
// This file must live in a folder named "Editor".
public static class AddCredits
{
    const string CreditsText =
        "CREDITS\n\n" +
        "Programming: Billy Sharpe, Emma Colwill, Lily/Bonnie Denise\n" +
        "2D Art & Narrative Design: Anna Grosse\n" +
        "Environment & Backgrounds: Kelechi Ozuzu, Kadir Ozturk\n" +
        "UI Design: Jason Slim (Main Menu), Constantine Burgan (In-Game UI), Keady Van Zandt (Ending Screen)\n" +
        "Audio & Music: Gregory Lakota\n" +
        "Marketing: Sarah Griffin\n\n" +
        "Made for Wolfjam 2026";

    [MenuItem("Tools/Stranded Frequency/Add Credits")]
    public static void Add()
    {
        EndingScreen ending = Object.FindFirstObjectByType<EndingScreen>(FindObjectsInactive.Include);
        if (ending == null)
        {
            EditorUtility.DisplayDialog("No ending screen found",
                "Open the Ending_Keady scene first, then run this again.", "OK");
            return;
        }

        Transform panel = ending.transform;
        Transform existing = panel.Find("Credits");
        if (existing != null)
        {
            bool replace = EditorUtility.DisplayDialog("Credits already exist",
                "Replace the existing Credits text with a fresh one? (Cmd+Z undoes this.)", "Replace", "Cancel");
            if (!replace) return;
            Undo.DestroyObjectImmediate(existing.gameObject);
        }

        GameObject go = new GameObject("Credits", typeof(RectTransform));
        go.layer = LayerMask.NameToLayer("UI");
        go.transform.SetParent(panel, false);

        // Same spot as the subtitles (right of Furcifer). Subtitles are cleared before credits show.
        RectTransform rt = (RectTransform)go.transform;
        rt.anchorMin = rt.anchorMax = rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = new Vector2(380, -55);
        rt.sizeDelta = new Vector2(760, 460);

        Text t = go.AddComponent<Text>();
        Font body = FindFont("SourceSans3-Regular");
        t.font = body != null ? body : Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        t.text = CreditsText;
        t.fontSize = 28;
        t.lineSpacing = 1.15f;
        ColorUtility.TryParseHtmlString("#D4F7F4", out Color c);
        t.color = c;
        t.alignment = TextAnchor.MiddleLeft;
        t.horizontalOverflow = HorizontalWrapMode.Wrap;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.raycastTarget = false;

        // Put it right after the Subtitles in the Hierarchy
        Transform subs = panel.Find("Subtitles");
        if (subs != null) go.transform.SetSiblingIndex(subs.GetSiblingIndex() + 1);

        Undo.RegisterCreatedObjectUndo(go, "Add Credits");
        Undo.RecordObject(ending, "Add Credits");
        ending.credits = go;
        EditorUtility.SetDirty(ending);

        // Hidden while editing so it doesn't cover the subtitles; the ending shows it at the right time
        go.SetActive(false);

        EditorSceneManager.MarkSceneDirty(panel.gameObject.scene);
        Selection.activeGameObject = go;
        Debug.Log("Credits added. Edit the names in the Credits Text box. They appear after Furcifer's message.");
    }

    static Font FindFont(string fileName)
    {
        foreach (string guid in AssetDatabase.FindAssets(fileName + " t:Font"))
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            if (System.IO.Path.GetFileNameWithoutExtension(path) == fileName)
                return AssetDatabase.LoadAssetAtPath<Font>(path);
        }
        return null;
    }
}
#endif
