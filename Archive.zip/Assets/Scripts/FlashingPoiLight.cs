using UnityEngine;
using UnityEngine.Rendering.Universal;

public class FlashingPoiLight : MonoBehaviour
{
    public float minIntensity = 0.15f;
    public float maxIntensity = 1.4f;
    public float flashesPerSecond = 1.5f;
    [Range(0f, 1f)]
    public float randomness = 0.5f;

    Light2D light2D;
    float rate;
    float phase;

    void Awake()
    {
        light2D = GetComponent<Light2D>();
        rate = flashesPerSecond * Random.Range(1f - randomness, 1f + randomness);
        phase = Random.Range(0f, Mathf.PI * 2f);
    }

    void Update()
    {
        if (light2D == null)
            return;

        float pulse = (Mathf.Sin(Time.time * rate * Mathf.PI * 2f + phase) + 1f) * 0.5f;
        light2D.intensity = Mathf.Lerp(minIntensity, maxIntensity, pulse);
    }
}
