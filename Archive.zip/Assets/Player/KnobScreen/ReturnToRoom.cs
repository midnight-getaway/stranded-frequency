using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

public class ReturnToRoom : MonoBehaviour
{
    public string roomScene = "SampleScene";

    void Start()
    {
        if (!PuzzleMemory.hasKnobState)
            return;

        SetKnob("LeftKnob", PuzzleMemory.leftKnobAngle);
        SetKnob("RightKnob", PuzzleMemory.rightKnobAngle);
        SetKnob("Right Knob", PuzzleMemory.rightKnobAngle);

        GameObject wave = GameObject.Find("Wave");
        if (wave != null)
            wave.transform.position = PuzzleMemory.wavePosition;
    }

    void Update()
    {
        if (Keyboard.current == null || !Keyboard.current.escapeKey.wasPressedThisFrame)
            return;

        SaveKnobs();

        string scene = string.IsNullOrEmpty(PuzzleMemory.returnScene)
            ? roomScene
            : PuzzleMemory.returnScene;

        SceneManager.LoadScene(scene);
    }

    void SaveKnobs()
    {
        GameObject left = GameObject.Find("LeftKnob");
        GameObject right = GameObject.Find("RightKnob");
        if (right == null)
            right = GameObject.Find("Right Knob");
        GameObject wave = GameObject.Find("Wave");

        if (left != null)
            PuzzleMemory.leftKnobAngle = left.transform.eulerAngles.z;

        if (right != null)
            PuzzleMemory.rightKnobAngle = right.transform.eulerAngles.z;

        if (wave != null)
            PuzzleMemory.wavePosition = wave.transform.position;

        PuzzleMemory.hasKnobState = true;
    }

    void SetKnob(string objectName, float angle)
    {
        GameObject knob = GameObject.Find(objectName);
        if (knob == null)
            return;

        knob.transform.rotation = Quaternion.Euler(0f, 0f, angle);
    }
}