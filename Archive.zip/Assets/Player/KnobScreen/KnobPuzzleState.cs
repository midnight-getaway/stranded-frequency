using UnityEngine;

public class KnobPuzzleState : MonoBehaviour
{
    public static KnobPuzzleState Instance { get; private set; }

    public Transform leftKnob;
    public Transform rightKnob;
    public Transform wave;

    void Awake()
    {
        Instance = this;

        if (!PuzzleMemory.hasKnobState)
            return;

        if (leftKnob != null)
            leftKnob.rotation = Quaternion.Euler(0f, 0f, PuzzleMemory.leftKnobAngle);

        if (rightKnob != null)
            rightKnob.rotation = Quaternion.Euler(0f, 0f, PuzzleMemory.rightKnobAngle);

        if (wave != null)
            wave.position = PuzzleMemory.wavePosition;
    }

    void LateUpdate()
    {
        Save();
    }

    public void Save()
    {
        if (leftKnob != null)
            PuzzleMemory.leftKnobAngle = leftKnob.eulerAngles.z;

        if (rightKnob != null)
            PuzzleMemory.rightKnobAngle = rightKnob.eulerAngles.z;

        if (wave != null)
            PuzzleMemory.wavePosition = wave.position;

        PuzzleMemory.hasKnobState = leftKnob != null || rightKnob != null || wave != null;
    }
}