using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Tilemaps;

public class CharacterMover : MonoBehaviour
{
    public Grid grid;
    public Tilemap walkable;
    public Tilemap[] blocked;
    public float speed = 3f;

    GameControls controls;
    Vector3Int cell;
    Vector3 target;
    bool moving;

    void Awake()
    {
        controls = new GameControls();
    }

    void OnEnable()
    {
        controls.Player.Enable();
    }

    void OnDisable()
    {
        controls.Player.Disable();
    }

    void OnDestroy()
    {
        controls.Dispose();
    }

    void Start()
    {
        cell = grid.WorldToCell(transform.position);
        cell.z = 0;
        transform.position = CenterOf(cell);
    }

    void Update()
    {
        if (controls == null)
            return;

        if (moving)
        {
            transform.position = Vector3.MoveTowards(transform.position, target, speed * Time.deltaTime);
            if (transform.position == target)
                moving = false;
            return;
        }

        Vector3Int step = DirectionFrom(controls.Player.Move.ReadValue<Vector2>());
        if (step == Vector3Int.zero)
            return;

        Vector3Int next = cell + step;
        if (!CanWalk(next))
            return;

        cell = next;
        target = CenterOf(cell);
        moving = true;
    }

    Vector3Int DirectionFrom(Vector2 input)
    {
        if (input.sqrMagnitude < 0.01f)
            return Vector3Int.zero;

        if (Mathf.Abs(input.x) > Mathf.Abs(input.y))
            return input.x > 0
                ? new Vector3Int(0, -1, 0)
                : new Vector3Int(0, 1, 0);

        return input.y > 0
            ? new Vector3Int(1, 0, 0)
            : new Vector3Int(-1, 0, 0);
    }

    bool CanWalk(Vector3Int next)
    {
        if (walkable == null || !walkable.HasTile(next))
            return false;

        if (blocked == null)
            return true;

        Vector3 world = CenterOf(next);
        foreach (Tilemap map in blocked)
        {
            if (map == null)
                continue;

            Vector3Int blockedCell = map.WorldToCell(world);
            blockedCell.z = 0;
            if (map.HasTile(blockedCell))
                return false;
        }

        return true;
    }

    Vector3 CenterOf(Vector3Int tileCell)
    {
        Vector3 center = grid.GetCellCenterWorld(tileCell);
        center.z = 0f;
        return center;
    }

    void OnDrawGizmos()
    {
        if (grid == null)
            return;

        Vector3Int tile = grid.WorldToCell(transform.position);
        tile.z = 0;

        Gizmos.color = Color.yellow;
        Gizmos.DrawSphere(grid.GetCellCenterWorld(tile), 0.05f);
    }
}