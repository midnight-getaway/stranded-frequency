using UnityEngine;

public class CharacterFacing : MonoBehaviour
{
    public Sprite upSprite;
    public Sprite downSprite;
    public Sprite leftSprite;
    public Sprite rightSprite;

    SpriteRenderer spriteRenderer;
    GameControls controls;
    Sprite current;

    void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        controls = new GameControls();
    }

    void OnEnable()
    {
        controls.Player.Enable();
    }

    void OnDisable()
    {
        controls.Player.Disable();
    }

    void OnDestroy()
    {
        controls.Dispose();
    }

    void Start()
    {
        current = downSprite;
        if (current != null)
            spriteRenderer.sprite = current;
    }

void Update()
{
    Vector2 input = controls.Player.Move.ReadValue<Vector2>();
    if (input.sqrMagnitude < 0.01f)
        return;

    bool flipLeft = false;
    Sprite next;

    if (Mathf.Abs(input.x) > Mathf.Abs(input.y))
    {
        next = rightSprite;
        flipLeft = input.x < 0;
    }
    else
    {
        next = input.y > 0 ? upSprite : downSprite;
    }

    if (next == null)
        return;

    current = next;
    spriteRenderer.sprite = next;
    spriteRenderer.flipX = flipLeft;
}
}