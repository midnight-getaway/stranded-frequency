using UnityEngine;

public class ReturnFromPuzzle : MonoBehaviour
{
    void Start()
    {
        if (!PuzzleMemory.hasReturn)
            return;

        transform.position = PuzzleMemory.returnPosition;
        PuzzleMemory.hasReturn = false;
    }
}