using System.Collections;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class InteractPoint : MonoBehaviour
{
    public Grid grid;
    public Transform player;
    public Text message;
    public UnityEvent onInteract;

    GameControls controls;
    Coroutine hideRoutine;

    void Awake()
    {
        controls = new GameControls();
    }

    void Start()
    {
        if (message != null)
            message.gameObject.SetActive(false);
    }

    void OnEnable()
    {
        controls.Player.Enable();
    }

    void OnDisable()
    {
        controls.Player.Disable();
    }

    void OnDestroy()
    {
        controls.Dispose();
    }

    void Update()
    {
        if (controls == null || player == null || grid == null)
            return;

        if (!controls.Player.Interact.WasPressedThisFrame())
            return;

        Vector3Int playerCell = grid.WorldToCell(player.position);
        Vector3Int spotCell = grid.WorldToCell(transform.position);
        playerCell.z = 0;
        spotCell.z = 0;

        if (playerCell != spotCell)
            return;

        ShowMessage();
        onInteract.Invoke();
    }

    void ShowMessage()
    {
        if (message == null)
            return;

        //message.text = "You pressed a button";
        //message.gameObject.SetActive(true);

        if (hideRoutine != null)
            StopCoroutine(hideRoutine);

        hideRoutine = StartCoroutine(HideAfterDelay());
    }

    IEnumerator HideAfterDelay()
    {
        yield return new WaitForSeconds(2f);
        message.gameObject.SetActive(false);
    }

    void OnDrawGizmos()
    {
        Gizmos.color = new Color(1f, 0.85f, 0.2f, 0.9f);
        Gizmos.DrawWireSphere(transform.position, 0.25f);
    }
}