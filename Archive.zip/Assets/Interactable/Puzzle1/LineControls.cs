using UnityEngine;

public class WaveDisplay : MonoBehaviour
{
    public Transform leftKnob;
    public Transform rightKnob;
    public int points = 120;
    public float width = 8f;

    LineRenderer core;
    LineRenderer glow;

    void Awake()
    {
        core = GetComponent<LineRenderer>();
        SetupLine(core, 0.045f, new Color(0.6f, 1f, 0.45f, 1f), 11);

        var glowObject = new GameObject("WaveGlow");
        glowObject.transform.SetParent(transform, false);
        glow = glowObject.AddComponent<LineRenderer>();
        SetupLine(glow, 0.22f, new Color(0.15f, 1f, 0.2f, 0.28f), 10);
    }

    void SetupLine(LineRenderer line, float lineWidth, Color color, int order)
    {
        line.positionCount = points;
        line.useWorldSpace = false;
        line.startWidth = lineWidth;
        line.endWidth = lineWidth;
        line.startColor = color;
        line.endColor = color;
        line.sortingOrder = order;
        line.numCapVertices = 4;
        line.material = new Material(Shader.Find("Sprites/Default"));
    }

    void Update()
    {
        float frequency = KnobValue(leftKnob, 1f, 8f);
        float amplitude = KnobValue(rightKnob, 0.15f, 1.5f);

        for (int i = 0; i < points; i++)
        {
            float t = i / (float)(points - 1);
            float x = Mathf.Lerp(-width * 0.5f, width * 0.5f, t);
            float y = Mathf.Sin(t * frequency * Mathf.PI * 2f) * amplitude;
            Vector3 position = new Vector3(x, y, 0f);
            core.SetPosition(i, position);
            glow.SetPosition(i, position);
        }
    }

    float KnobValue(Transform knob, float min, float max)
    {
        Knob dial = knob.GetComponent<Knob>();
        float minAngle = dial != null ? dial.minAngle : 0f;
        float maxAngle = dial != null ? dial.maxAngle : 359f;
        float turn = Mathf.InverseLerp(minAngle, maxAngle, knob.eulerAngles.z);
        return Mathf.Lerp(min, max, turn);
    }
}