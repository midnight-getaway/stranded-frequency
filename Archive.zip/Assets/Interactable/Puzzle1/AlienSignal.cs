using UnityEngine;
using UnityEngine.InputSystem;

public class NamePuzzle : MonoBehaviour
{
    public Knob leftKnob;
    public Knob rightKnob;
    public int tolerance = 10;
    public float width = 8f;
    //public Vector3 letterOffset = new Vector3(0f, 2.4f, 0f);
    public Vector3 spelledOffset = new Vector3(-2f, -2.4f, 0f);

    static readonly char[] Letters = { 'F', 'U', 'R', 'C', 'I', 'F', 'E', 'R' };
    static readonly int[] Left = { 50, 260, 190, 50, 120, 50, 50, 190 };
    static readonly int[] Right = { 315, 95, 315, 150, 150, 315, 260, 315 };

    LineRenderer alienCore;
    LineRenderer alienGlow;
    TextMesh spelledLabel;
    GameControls controls;
    int index;
    float wrongUntil;
    string spelled = "";

    void Awake()
    {
        controls = new GameControls();
    }

    void OnEnable()
    {
        controls.Player.Enable();
    }

    void OnDisable()
    {
        controls.Player.Disable();
    }

    void OnDestroy()
    {
        controls.Dispose();
    }

    void Start()
    {
        int points = 120;
        LineRenderer green = GetComponent<LineRenderer>();
        if (green != null)
            points = green.positionCount;

        alienGlow = MakeLine("AlienGlow", 0.22f, new Color(0.2f, 0.45f, 1f, 0.28f), 5, points);
        alienCore = MakeLine("AlienCore", 0.045f, new Color(0.45f, 0.75f, 1f, 1f), 6, points);
        //letterLabel = MakeLabel("CurrentLetter", letterOffset, 0.08f);
        spelledLabel = MakeLabel("SpelledName", spelledOffset, 0.045f);
        //ShowLetter();
    }

    void Update()
    {
        if (spelledLabel != null)
            spelledLabel.transform.localPosition = spelledOffset;

        if (index >= Letters.Length)
            return;

        DrawAlien();

        bool enter = Keyboard.current != null && Keyboard.current.enterKey.wasPressedThisFrame;
        bool interact = controls.Player.Interact.WasPressedThisFrame();
        if (enter || interact)
            LockIn();

        // letterLabel.color = Time.time < wrongUntil
        //     ? Color.red
        //     : new Color(0.45f, 0.75f, 1f);
    }

    void LockIn()
    {
        int left = KnobNumber(leftKnob);
        int right = KnobNumber(rightKnob);
        bool match = Mathf.Abs(left - Left[index]) <= tolerance
            && Mathf.Abs(right - Right[index]) <= tolerance;

        if (!match)
        {
            wrongUntil = Time.time + 0.6f;
            return;
        }

        spelled += Letters[index];
        spelledLabel.text = spelled;
        index++;

        if (index >= Letters.Length)
        {
            alienCore.gameObject.SetActive(false);
            alienGlow.gameObject.SetActive(false);
        }
    }


    void Draw(LineRenderer line, float frequency, float amplitude)
    {
        int points = line.positionCount;
        for (int i = 0; i < points; i++)
        {
            float t = i / (float)(points - 1);
            float x = Mathf.Lerp(-width * 0.5f, width * 0.5f, t);
            float y = Mathf.Sin(t * frequency * Mathf.PI * 2f) * amplitude;
            line.SetPosition(i, new Vector3(x, y, 0f));
        }
    }

    int KnobNumber(Knob knob)
    {
        float turn = Mathf.InverseLerp(knob.minAngle, knob.maxAngle, knob.transform.eulerAngles.z);
        return Mathf.RoundToInt(Mathf.Lerp(1f, 354f, turn));
    }

    LineRenderer MakeLine(string name, float lineWidth, Color color, int order, int points)
    {
        var child = new GameObject(name);
        child.transform.SetParent(transform, false);
        LineRenderer line = child.AddComponent<LineRenderer>();
        line.positionCount = points;
        line.useWorldSpace = false;
        line.startWidth = lineWidth;
        line.endWidth = lineWidth;
        line.startColor = color;
        line.endColor = color;
        line.sortingOrder = order;
        line.numCapVertices = 4;
        line.material = new Material(Shader.Find("Sprites/Default"));
        return line;
    }

    TextMesh MakeLabel(string name, Vector3 localPosition, float characterSize)
    {
        var child = new GameObject(name);
        child.transform.SetParent(transform, false);
        child.transform.localPosition = localPosition;
        TextMesh mesh = child.AddComponent<TextMesh>();
        mesh.anchor = TextAnchor.MiddleCenter;
        mesh.alignment = TextAlignment.Center;
        mesh.characterSize = characterSize;
        mesh.fontSize = 100;
        mesh.color = Color.white;
        mesh.GetComponent<MeshRenderer>().sortingOrder = 20;
        return mesh;
    }
    float TurnFromChart(Knob knob, int number)
    {
        KnobOutput readout = knob.GetComponent<KnobOutput>();
        float minimum = readout != null ? readout.minimum : 1f;
        float maximum = readout != null ? readout.maximum : 354f;
        return Mathf.InverseLerp(minimum, maximum, number);
    }

    void DrawAlien()
    {
        float frequency = Mathf.Lerp(1f, 8f, TurnFromChart(leftKnob, Left[index]));
        float amplitude = Mathf.Lerp(0.15f, 1.5f, TurnFromChart(rightKnob, Right[index]));
        Draw(alienCore, frequency, amplitude);
        Draw(alienGlow, frequency, amplitude);
    }
}