using UnityEngine;

[RequireComponent(typeof(AudioSource))]
public class KnobTone : MonoBehaviour
{
    public Knob leftKnob;
    public Knob rightKnob;

    float frequency = 220f;
    float amplitude = 0.1f;
    double phase;
    int sampleRate;

    void Start()
    {
        sampleRate = AudioSettings.outputSampleRate;

        AudioSource source = GetComponent<AudioSource>();
        source.playOnAwake = false;
        source.loop = true;
        source.spatialBlend = 0f;

        source.clip = AudioClip.Create("KnobTone", sampleRate, 1, sampleRate, true, OnRead);
        source.Play();
    }

    void Update()
    {
        if (leftKnob != null)
        {
            float turn = Mathf.InverseLerp(leftKnob.minAngle, leftKnob.maxAngle, leftKnob.transform.eulerAngles.z);
            frequency = Mathf.Lerp(110f, 880f, turn);
        }

        if (rightKnob != null)
        {
            float turn = Mathf.InverseLerp(rightKnob.minAngle, rightKnob.maxAngle, rightKnob.transform.eulerAngles.z);
            amplitude = Mathf.Lerp(0f, 0.25f, turn);
        }
    }

    void OnRead(float[] data)
    {
        double step = frequency / sampleRate;

        for (int i = 0; i < data.Length; i++)
        {
            data[i] = Mathf.Sin((float)(phase * Mathf.PI * 2.0)) * amplitude;
            phase += step;
            if (phase > 1.0)
                phase -= 1.0;
        }
    }
}