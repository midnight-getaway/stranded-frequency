using UnityEngine;

public static class PuzzleMemory
{
    public static string returnScene;
    public static Vector3 returnPosition;
    public static bool hasReturn;
    public static bool knobsSolved;

    public static bool hasKnobState;
    public static float leftKnobAngle;
    public static float rightKnobAngle;
    public static Vector3 wavePosition;
}