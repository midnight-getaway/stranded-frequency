using UnityEngine;
using UnityEngine.InputSystem;

public class Knob : MonoBehaviour
{
    public float sensitivity = 0.35f;
    public float minAngle = 0f;
    public float maxAngle = 359f;
    public int step = 5;

    bool turning;
    float lastPointerAngle;
    float knobAngle;
    KnobOutput readout;

    void Awake()
    {
        readout = GetComponent<KnobOutput>();
        knobAngle = transform.eulerAngles.z;
        transform.rotation = Quaternion.Euler(0f, 0f, SnappedAngle(knobAngle));
    }

    void Update()
    {
        if (Mouse.current == null || Camera.main == null)
            return;

        if (Mouse.current.leftButton.wasPressedThisFrame && PointerIsOverThis())
        {
            turning = true;
            lastPointerAngle = PointerAngle();
            knobAngle = transform.eulerAngles.z;
        }

        if (Mouse.current.leftButton.wasReleasedThisFrame)
            turning = false;

        if (!turning)
            return;

        float pointerAngle = PointerAngle();
        float delta = Mathf.DeltaAngle(lastPointerAngle, pointerAngle);
        lastPointerAngle = pointerAngle;

        knobAngle = Mathf.Clamp(knobAngle + delta * sensitivity, minAngle, maxAngle);
        transform.rotation = Quaternion.Euler(0f, 0f, SnappedAngle(knobAngle));
    }

    float SnappedAngle(float angle)
    {
        float minimum = readout != null ? readout.minimum : 1f;
        float maximum = readout != null ? readout.maximum : 354f;
        float turn = Mathf.InverseLerp(minAngle, maxAngle, angle);
        float number = Mathf.Lerp(minimum, maximum, turn);

        float first = Mathf.Ceil(minimum / step) * step;
        float last = Mathf.Floor(maximum / step) * step;
        float snapped = Mathf.Clamp(Mathf.Round(number / step) * step, first, last);
        float snappedTurn = Mathf.InverseLerp(minimum, maximum, snapped);
        return Mathf.Lerp(minAngle, maxAngle, snappedTurn);
    }

    float PointerAngle()
    {
        Vector2 screen = Mouse.current.position.ReadValue();
        Vector3 world = Camera.main.ScreenToWorldPoint(
            new Vector3(screen.x, screen.y, -Camera.main.transform.position.z));
        Vector2 direction = (Vector2)world - (Vector2)transform.position;
        return Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
    }

    bool PointerIsOverThis()
    {
        Vector2 screen = Mouse.current.position.ReadValue();
        Vector3 world = Camera.main.ScreenToWorldPoint(
            new Vector3(screen.x, screen.y, -Camera.main.transform.position.z));

        Collider2D hit = Physics2D.OverlapPoint(world);
        return hit != null && hit.transform == transform;
    }
}