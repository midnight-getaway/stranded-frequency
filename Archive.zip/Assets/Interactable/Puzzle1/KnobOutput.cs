using UnityEngine;

public class KnobOutput : MonoBehaviour
{
    public Knob knob;
    public TextMesh label;
    public int minimum = 1;
    public int maximum = 364;
    public Vector3 offset = new Vector3(0f, 0.8f, 0f);

    void LateUpdate()
    {
        if (knob == null || label == null)
            return;

        float turn = Mathf.InverseLerp(knob.minAngle, knob.maxAngle, knob.transform.eulerAngles.z);
        int number = Mathf.RoundToInt(Mathf.Lerp(minimum, maximum, turn));

        label.text = number.ToString();
        label.transform.position = knob.transform.position + offset;
        label.transform.rotation = Quaternion.identity;
    }
}