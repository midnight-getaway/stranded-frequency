using UnityEngine;
using UnityEngine.SceneManagement;

public class OpenPuzzle : MonoBehaviour
{
    public string puzzleScene = "KnobPuzzle";
    public Transform player;

    public void Open()
    {
        if (PuzzleMemory.knobsSolved)
            return;

        PuzzleMemory.returnScene = SceneManager.GetActiveScene().name;
        PuzzleMemory.returnPosition = player.position;
        PuzzleMemory.hasReturn = true;
        SceneManager.LoadScene(puzzleScene);
    }
}