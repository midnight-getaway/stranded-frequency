using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ShowSliderValue : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI valueText;
    [SerializeField] private int step;
    [SerializeField] private Slider slider;

    void Start()
    {
        slider.onValueChanged.AddListener(UpdateText);
        UpdateText(slider.value * step);
    }

    public void UpdateText(float value)
    {
        valueText.text = $"{value * step}";
    }
}
