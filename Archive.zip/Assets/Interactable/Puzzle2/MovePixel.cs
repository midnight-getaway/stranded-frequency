using UnityEngine;
using UnityEngine.UI;

public class MovePixel : MonoBehaviour
{
    [SerializeField] private Slider xSlider;
    [SerializeField] private Slider ySlider;
    [SerializeField] private GameObject imageFrame;
    [SerializeField] private int step;
    [SerializeField] private int xCorrect;
    [SerializeField] private int yCorrect;

    float increment;
    Vector2 solvedPos;

    void Start()
    {
        solvedPos = transform.position;
        increment = imageFrame.GetComponent<SpriteRenderer>().bounds.size.x / (xSlider.maxValue * step)
            - gameObject.GetComponent<SpriteRenderer>().bounds.size.x / (xSlider.maxValue * step);
        increment *= 0.6f;

        if (xSlider != null)
        {
            xSlider.onValueChanged.AddListener(MoveX);
            MoveX(xSlider.value);
        }
        if (ySlider != null)
        {
            ySlider.onValueChanged.AddListener(MoveY);
            MoveY(ySlider.value);
        }
    }

    public void MoveX(float value)
    {
        float number = value * step;
        transform.position = new Vector2(
            solvedPos.x + (number - xCorrect) * increment,
            transform.position.y);
    }

    public void MoveY(float value)
    {
        float number = value * step;
        transform.position = new Vector2(
            transform.position.x,
            solvedPos.y - (number - yCorrect) * increment);
    }
}
