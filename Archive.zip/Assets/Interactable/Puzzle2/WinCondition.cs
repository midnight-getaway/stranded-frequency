using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class WinCondition : MonoBehaviour
{
    [SerializeField] private List<Slider> slidersList;
    [SerializeField] private List<GameObject> pixelList;
    [SerializeField] private List<int> winValuesArray;
    [SerializeField] private int step;
    [SerializeField] private SpriteRenderer furcifer;
    [SerializeField] private float duration;
    private float timer = 0f;
    private bool puzzleComplete = false;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        winValuesArray = new List<int>();
        winValuesArray.Add(50);
        winValuesArray.Add(315);
        winValuesArray.Add(260);
        winValuesArray.Add(95);
        winValuesArray.Add(190);
        winValuesArray.Add(315);
        winValuesArray.Add(50);
        winValuesArray.Add(150);
        winValuesArray.Add(120);
        winValuesArray.Add(150);
        winValuesArray.Add(50);
        winValuesArray.Add(315);
        winValuesArray.Add(50);
        winValuesArray.Add(260);
        winValuesArray.Add(190);
        winValuesArray.Add(315);
    }

    // Update is called once per frame
    void Update()
    {
        CheckWin();
    }

    void FixedUpdate()
    {
        if (puzzleComplete)
        {
            if (timer < duration)
            {
                timer += Time.fixedDeltaTime;
            }
            else
            {
                SceneManager.LoadScene("Ending_Keady");
            }
        }
    }

    private void CheckWin()
    {
        for(int i = 0; i < winValuesArray.Count; i++)
        {
            if (slidersList[i].value * step != winValuesArray[i])
            {
                return;
            }
        }

        for(int i = 0; i < slidersList.Count; i++)
        {
            slidersList[i].interactable = false;
        }

        puzzleComplete = true;
        furcifer.enabled = true;
        for(int i = 0; i < pixelList.Count; i++)
        {
            pixelList[i].GetComponent<SpriteRenderer>().enabled = false;
        }
    }
}
